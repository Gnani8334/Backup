package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.DrSmartException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDao dao = new DoctorAppointmentDao();

	static String namePattern = "[A-Z]{1}[a-z]{2,}";
	static String numberPattern = "[1-9][0-9]{9}";

	
	enum genderPattern {
		male, female
	};

	private genderPattern gender;

	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {

		if (doctorAppointment.getProblemName().equalsIgnoreCase("heart")) {
			doctorAppointment.setDoctorName("Dr. Brijesh Kumar");
			doctorAppointment.setAppointmentStatus("Approved");
		} else if (doctorAppointment.getProblemName().equalsIgnoreCase(
				"gynecology")) {

			doctorAppointment.setDoctorName("Dr. Sharada Singh");
			doctorAppointment.setAppointmentStatus("Approved");

		} else if (doctorAppointment.getProblemName().equalsIgnoreCase(
				"diabetes")) {
			doctorAppointment.setDoctorName("Dr. Heena Khan");
			doctorAppointment.setAppointmentStatus("Approved");

		} else if (doctorAppointment.getProblemName().equalsIgnoreCase("ent")) {
			doctorAppointment.setDoctorName("Dr. Paras mal");
			doctorAppointment.setAppointmentStatus("Approved");
		} else if (doctorAppointment.getProblemName().equalsIgnoreCase("Bone")) {
			doctorAppointment.setDoctorName("Dr. Renuka Kher");
			doctorAppointment.setAppointmentStatus("Approved");
		} else if (doctorAppointment.getProblemName().equalsIgnoreCase(
				"Dermatology")) {
			doctorAppointment.setDoctorName("Dr.Kanika Kapoor");
			doctorAppointment.setAppointmentStatus("Approved");

		}

		else {
			doctorAppointment.setDoctorName(null);
			doctorAppointment.setAppointmentStatus("DisApproved");

		}
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		if (name.matches(namePattern))
			return true;
		else
			return false;
	}

	public boolean validatePhoneNumber(String number) {
		// TODO Auto-generated method stub
		if (number.matches(numberPattern))
			return true;
		else
			return false;
	}

	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		if (email.endsWith(".com"))
			return true;
		else
			return false;
	}

	public boolean validateAge(int age) {
		// TODO Auto-generated method stub
		if (age >=1 && age <= 110)
			return true;
		else
			return false;
	}

	public boolean validateGender(String gender) throws DrSmartException {
		// TODO Auto-generated method stub
		try {
			this.gender = genderPattern.valueOf(gender);

			return true;
		} catch (IllegalArgumentException e) {
			throw new DrSmartException("Incorrect gender");
		}
	}

	public DoctorAppointment getDoctorAppointmentDetails(int appointmentid)
			throws DrSmartException {
		return dao.getDoctorAppointmentDetails(appointmentid);
		// TODO Auto-generated method stub

	}

	public DoctorAppointment updatePatientDetails(int appointmentid,int age) throws DrSmartException {
		// TODO Auto-generated method stub
		return dao.updatePatientDetails(appointmentid,age);
	}

	

}
