package com.capgemini.doctors.Test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.DrSmartException;

public class DaoTest {
	DoctorAppointmentDao doctorDao;
	DoctorAppointment doctorAppointmentobj;
	DoctorAppointment doctorAppointmentobj1 ;

	@Before
	public void setUp() throws Exception {
		 doctorDao=new DoctorAppointmentDao();
	}

	@After
	public void tearDown() throws Exception {
		doctorDao=null;
		
		
	}

	@Test
	public void testAddDoctorAppointmentDetails() {
		//fail("Not yet implemented");
		doctorAppointmentobj=new DoctorAppointment(19132,"Gnani","9553075484","gnans@gmail.com","female",20,"heart","Brijesh Kumar","Approved");
	
	doctorDao.addDoctorAppointmentDetails(doctorAppointmentobj);
	Assert.assertNotNull(doctorAppointmentobj);
		
		
	}

	@Test
	public void testGetDoctorAppointmentDetails()  {
		//fail("Not yet implemented");
		
	
	try {
		doctorAppointmentobj1= doctorDao.getDoctorAppointmentDetails(19136);
	} catch (DrSmartException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		System.out.println("Appointment Id not found");
	}
	
	Assert.assertNull(doctorAppointmentobj1);
		
	}

	@Test
	public void testUpdatePatientDetails() {
		//fail("Not yet implemented");
	}

}
