package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	
	Map<Integer, DoctorAppointment> appointments = new HashMap<Integer, DoctorAppointment>();
	DoctorAppointment a = new DoctorAppointment();

	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		doctorAppointment.getAppointmentId();
		appointments.put(doctorAppointment.getAppointmentId(),
				doctorAppointment);
		
		return doctorAppointment.getAppointmentId();
	}

	public DoctorAppointment getDoctorAppointmentDetails(int appointmentid)
			throws DrSmartException {

		if (appointments.containsKey(appointmentid)) {
			return appointments.get(appointmentid);
		} else
			throw new DrSmartException("NO appointment Found:");

	}

	public DoctorAppointment updatePatientDetails(int appointmentid, int age)
			throws DrSmartException {
		// TODO Auto-generated method stub
		if (appointments.containsKey(appointmentid)) {
			// System.out.println(appointments.get(age));
			
			DoctorAppointment c= appointments.get(appointmentid);
			c.setAge(age);
			appointments.put(appointmentid,c);
					
			appointments.remove(appointmentid);

			return appointments.get(appointmentid);
		} else
			throw new DrSmartException("NO appointment Found:");

	}

}
